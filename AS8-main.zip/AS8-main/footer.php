<!DOCTYPE html>
<html>
<head>

</head>
<body>

<section id='footer'>

    <div class="column-3-div">
        <img class='logo-footer' src="website_img/Touch & Huyak logo HD.png">
        <p>Our company is all about bringing new technologies to simple things and combining them for fun </p>
    </div>
    <div class="column-3-div">
        <h4>Quick Links</h4>
        <a>Categories</a>
        <br>
        <a>NFC Cards</a>
        <br>
        <a>Shop</a>
    </div>
    <div class="column-3-div">
        <h4>Other</h4>
        <a>Contact Us</a>
        <br>
        <a>Terms of Service</a>
        <br>
        <a href="#top">Back to Top</a>
    </div>

</section>

</body>


</html>